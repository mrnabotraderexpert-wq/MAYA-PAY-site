# MAYA-PAY pour Android

Coque Android native qui charge votre site MAYA-PAY et lui ajoute l'appel USSD direct sur la bonne SIM.

## 1. Mettre à jour le site (GitHub Pages)
Remplacez `app.js` à la racine de votre dépôt du site par le fichier `site-app.js` fourni (renommez-le `app.js`). Envoyez aussi les autres fichiers mis à jour du site (`index.html`, `style.css`, `link.js`, `api.js`, `sw.js`) (v1.5 : envoi de capture d'écran de confirmation) : le vendeur saisit désormais un numéro Orange et/ou Moov. Sans cette modification, l'application ouvre quand même le site, mais le paiement passe par le composeur.

## 2. Adresse du site
Déjà réglée sur `https://maya-pay.com/` dans `app/build.gradle`. Le HTTPS doit être actif (GitHub > Settings > Pages > Enforce HTTPS). Si le domaine change, modifiez les 3 lignes et recompilez.

## 3. Compiler sans ordinateur
1. Créez un dépôt GitHub (privé conseillé) et envoyez-y tout le contenu de ce dossier (le dossier `.github` compris).
2. Onglet **Actions** > « Compiler MAYA-PAY (APK) » > le travail démarre tout seul (≈ 5 min).
3. Ouvrez l'exécution terminée > **Artifacts** > `MAYA-PAY-apk` > installez `app-debug.apk`.

Cet APK est signé avec une clé de test : parfait pour vos essais. Pour le Play Store, il faudra une clé de signature et un `bundleRelease`.

## Ce que fait l'application
- Charge le site ; seuls les liens de votre site s'ouvrent dedans, le reste (WhatsApp, SMS…) part vers les applis du téléphone.
- Au clic sur Payer, le site appelle `MayaNative.dial(code, operateur)` ; l'application envoie l'USSD elle-même (`TelephonyManager.sendUssdRequest`) sur la SIM Orange ou Moov, sans composeur : le code et le numéro du vendeur ne s'affichent nulle part. La réponse de l'opérateur s'affiche dans une fenêtre de l'application. En cas d'échec, un bouton « Appel système » sert de secours.
- Seule la page de votre site peut déclencher un appel. Rien n'est stocké.
- **Capture d'écran (v1.5)** : l'application ouvre la galerie du téléphone quand le client choisit une capture à envoyer au vendeur (aucune permission supplémentaire). La page réduit l'image en JPEG avant l'envoi.

- **Vérification automatique Moov (v1.6)** : au premier paiement Moov, l'application demande l'autorisation « SMS » (RECEIVE_SMS). Pendant 10 minutes après le paiement, elle attend le SMS « Transfert d'argent réussi vers … ID: … » ; dès qu'il arrive, elle le remet à la page, qui l'envoie au serveur (montant, numéro du vendeur, référence unique). Le client n'a rien à coller. Les autres SMS sont ignorés (jamais transmis ni conservés), et la boîte de réception n'est pas lue. Si l'autorisation est refusée, le client colle le SMS comme avant. 
  - Remplacez aussi `app.js` du site par `site-app.js` (v1.9) et envoyez `sw.js`.
  - Cette permission convient à un APK installé directement ; Google Play restreint les permissions SMS.

## À tester sur de vrais téléphones
- **SMS Moov automatique** : faites un paiement test de 100 F sur Moov. Après le SMS, la page doit passer seule à « Paiement confirmé ». Testez aussi avec un montant différent (doit afficher « Montant ne correspond pas »).
- **Étape PIN** : `sendUssdRequest` ne permet pas de répondre à un menu USSD. Vérifiez sur Orange et Moov que le code direct aboutit sans réponse supplémentaire ; sinon utilisez le bouton « Appel système ».
- **Ouvrir le lien dans l'application** : un lien ouvert dans Chrome passe par le composeur (le code y est visible). Installez l'APK et ouvrez le lien avec MAYA-PAY.
- Double SIM Orange + Moov : la bonne SIM est-elle choisie ? (détection par nom d'opérateur et code réseau 610 01 / 610 02, à confirmer sur vos SIM)
- Selon la marque, le téléphone peut afficher brièvement un écran d'appel.
- **Capture d'écran** : testez le choix d'une image depuis la galerie, puis l'affichage côté vendeur (page de suivi > « Voir la capture »).
- Android 8 minimum ; iPhone : reste sur le site web.

- **Confirmation automatique Orange Money + Moov Money (v1.10)** : plus de saisie de SMS ni de capture d'écran. Avant de payer, la page appelle `MayaNative.armSms(lien, opérateur, filtre, 10)`. Le récepteur natif `SmsReceiver` (déclaré dans le manifeste, il fonctionne écran éteint) ne regarde que les SMS correspondant au filtre de l'opérateur, pendant 10 minutes, et envoie le SMS, sa date de réception et le numéro de la SIM directement au serveur (`mayapay_sms_v2`, 2 essais). Les autres SMS sont ignorés, jamais transmis ni conservés ; la boîte de réception n'est pas lue. Le filtre de chaque opérateur est dans Supabase (`mayapay.operators.sms_filter`) : un nouveau format de SMS se gère côté serveur, sans recompiler.
  - Autorisations demandées : SMS (RECEIVE_SMS) et numéros de téléphone (READ_PHONE_NUMBERS, pour comparer le numéro de la SIM au numéro déclaré par le client).
  - Remplacez `app.js` du site par `site-app.js` et envoyez aussi `index.html`, `style.css`, `api.js`, `link.js`, `config.js`, `sw.js`.

## À tester sur de vrais téléphones
- Paiement de 100 F sur Orange puis sur Moov : la page doit passer seule à « Paiement confirmé » (ou « à vérifier » si le numéro expéditeur n'est pas établi).
- Numéro déclaré différent du numéro réel : le paiement doit être refusé (`payer_mismatch`).
- Écran éteint pendant le paiement ; autorisation SMS refusée (la page doit l'indiquer).

## v1.11 – Abonnements
Aucune modification native : l'application charge le site. Remplacez `app.js` du site par `site-app.js` (identique au nouveau `app.js`) et envoyez aussi `admin.html`, `admin.js`, `admin.css`, `api.js`, `index.html`, `style.css`, `sw.js`. Le paiement de l'abonnement utilise la même confirmation automatique par SMS.

- **Saisie du code secret (v1.11)** : le paiement passe désormais par l'appel système (`TelecomManager.placeCall`) sur la bonne SIM. La fenêtre USSD de l'opérateur (Orange Money / Moov Money) s'ouvre avec son champ de saisie : le client y tape son code secret. `sendUssdRequest` ne le permettait pas (menu sans possibilité de répondre). La confirmation SMS automatique reste inchangée.
