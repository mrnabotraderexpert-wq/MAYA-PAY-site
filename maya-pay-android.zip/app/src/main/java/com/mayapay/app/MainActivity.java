package com.mayapay.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Telephony;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * MAYA-PAY : coque Android autour du site. Elle charge le site et lui ajoute une seule capacité :
 * lancer le code USSD directement sur la bonne SIM (Orange / Moov), sans composeur visible.
 * Rien n'est stocké : le code reste en mémoire le temps de l'appel puis est effacé.
 */
public class MainActivity extends Activity {

    private static final Pattern USSD = Pattern.compile("^[0-9*#]{1,64}$");
    private static final int REQ_PERMS = 42;
    private static final int REQ_FILE = 43;

    private WebView web;

    // Sélecteur de fichier de la page (photo du vendeur), le temps du choix.
    private ValueCallback<Uri[]> filePathCallback;

    // En mémoire seulement, le temps de la demande de permission.
    private String pendingCode;
    private String pendingOp;
    private String currentOp;        // opérateur du paiement en cours

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " MayaPayApp/" + "1.0");

        web.addJavascriptInterface(new Bridge(), "MayaNative");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(startUrl(getIntent()));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        web.loadUrl(startUrl(intent));
    }

    private String startUrl(Intent intent) {
        Uri d = intent == null ? null : intent.getData();
        if (d != null && "https".equals(d.getScheme()) && BuildConfig.BASE_HOST.equalsIgnoreCase(d.getHost())) {
            return d.toString();
        }
        return BuildConfig.BASE_URL;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private boolean isTrustedPage() {
        String u = web.getUrl();
        if (u == null) return false;
        Uri uri = Uri.parse(u);
        return "https".equals(uri.getScheme()) && BuildConfig.BASE_HOST.equalsIgnoreCase(uri.getHost());
    }

    /* ---------- Pont JavaScript : le site appelle MayaNative.dial(code, operateur) ---------- */
    private class Bridge {
        @JavascriptInterface
        public boolean isApp() {
            return true;
        }

        /**
         * Prépare la détection automatique du SMS de confirmation pour ce paiement (10 min max).
         * linkId : identifiant du lien ; operator : orange | moov ; filter : regex fournie par le serveur.
         */
        @JavascriptInterface
        public void armSms(final String linkId, final String operator, final String filter, final int minutes) {
            runOnUiThread(() -> {
                if (!isTrustedPage()) return;
                if (linkId == null || !linkId.matches("[0-9a-f]{12}") || !wantsSms(operator)) return;
                if (filter != null && filter.length() > 400) return;
                SmsReceiver.arm(MainActivity.this, linkId, operator.toLowerCase(Locale.ROOT), filter, minutes);
            });
        }

        @JavascriptInterface
        public void disarmSms() {
            runOnUiThread(() -> { if (isTrustedPage()) SmsReceiver.disarm(MainActivity.this); });
        }

        /** Vrai si l'application peut lire les SMS de confirmation (autorisation accordée). */
        @JavascriptInterface
        public boolean smsReady() {
            return hasSmsPerm();
        }

        @JavascriptInterface
        public void dial(final String code, final String operator) {
            runOnUiThread(() -> {
                if (!isTrustedPage()) return; // seul votre site peut lancer un appel
                if (code == null || !USSD.matcher(code).matches()) {
                    toast("Code invalide.");
                    return;
                }
                startDial(code, operator);
            });
        }
    }

    /* ---------- Choix d'une image (photo du vendeur, input type=file de la page) ---------- */
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (!isTrustedPage()) { // seul votre site peut ouvrir le sélecteur
                callback.onReceiveValue(null);
                return true;
            }
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = callback;
            try {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                startActivityForResult(Intent.createChooser(pick, "Choisir une image"), REQ_FILE);
            } catch (Exception e) {
                filePathCallback = null;
                callback.onReceiveValue(null);
                toast("Impossible d'ouvrir la galerie.");
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FILE) return;
        ValueCallback<Uri[]> cb = filePathCallback;
        filePathCallback = null;
        if (cb == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            result = new Uri[]{data.getData()};
        }
        cb.onReceiveValue(result); // null si annulé : la page n'attend pas indéfiniment
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            if ("https".equals(scheme) && BuildConfig.BASE_HOST.equalsIgnoreCase(u.getHost())) {
                return false; // reste dans l'application
            }
            if ("tel".equals(scheme)) {
                // Secours : un lien tel: du site passe par le même chemin (SIM par défaut).
                String code = u.getSchemeSpecificPart();
                if (code != null && USSD.matcher(code).matches()) {
                    startDial(code, null);
                }
                return true;
            }
            // WhatsApp, SMS, partage, autres sites : applications du téléphone.
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
                toast("Impossible d'ouvrir ce lien.");
            }
            return true;
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
            if (req.isForMainFrame()) {
                String html = "<meta name=viewport content='width=device-width,initial-scale=1'>"
                        + "<body style='font-family:sans-serif;text-align:center;padding:48px 24px;background:#FAF8F5'>"
                        + "<h2 style='color:#FF7900'>MAYA-PAY</h2><p>Connexion impossible.</p>"
                        + "<p><a href='" + BuildConfig.BASE_URL + "'>Réessayer</a></p></body>";
                view.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }
        }
    }

    /* ---------- Appel USSD ---------- */
    private boolean hasPerms() {
        return checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasSmsPerm() {
        return checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private static boolean isMoov(String operator) {
        return "moov".equalsIgnoreCase(operator);
    }

    /** Moov et Orange : la lecture automatique du SMS de confirmation concerne les deux opérateurs. */
    private static boolean wantsSms(String operator) {
        return "moov".equalsIgnoreCase(operator) || "orange".equalsIgnoreCase(operator);
    }


    private void startDial(String code, String operator) {
        currentOp = operator;
        boolean askSms = wantsSms(operator) && !hasSmsPerm();
        if (!hasPerms() || askSms) {
            pendingCode = code;
            pendingOp = operator;
            java.util.ArrayList<String> need = new java.util.ArrayList<>();
            need.add(Manifest.permission.CALL_PHONE);
            need.add(Manifest.permission.READ_PHONE_STATE);
            if (wantsSms(operator)) {
                need.add(Manifest.permission.RECEIVE_SMS);
                need.add(Manifest.permission.READ_PHONE_NUMBERS);
            }
            requestPermissions(need.toArray(new String[0]), REQ_PERMS);
            return;
        }
        placeUssd(code, operator);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        String code = pendingCode, op = pendingOp;
        pendingCode = null;
        pendingOp = null;
        if (code != null && hasPerms()) {
            if (wantsSms(op) && !hasSmsPerm()) {
                toast("Autorisez la lecture des SMS : sans elle, le paiement ne peut pas être confirmé automatiquement.");
            }
            placeUssd(code, op);
        } else {
            toast("Autorisez l'accès au téléphone pour payer depuis l'application.");
        }
    }

    /**
     * Envoie le code USSD depuis l'application (TelephonyManager.sendUssdRequest) sur la SIM choisie :
     * aucun composeur, aucun écran d'appel, le code et le numéro du vendeur ne s'affichent nulle part.
     * Seule la réponse de l'opérateur est affichée.
     */
    private void placeUssd(final String code, final String operator) {
        try {
            SubscriptionManager sm = (SubscriptionManager) getSystemService(TELEPHONY_SUBSCRIPTION_SERVICE);
            @SuppressLint("MissingPermission")
            List<SubscriptionInfo> subs = sm == null ? null : sm.getActiveSubscriptionInfoList();
            if (subs == null || subs.isEmpty()) {
                toast("Aucune SIM active.");
                return;
            }
            if (subs.size() == 1) {
                sendUssd(code, subs.get(0).getSubscriptionId(), operator);
                return;
            }
            SubscriptionInfo match = matchSub(subs, operator);
            if (match != null) {
                sendUssd(code, match.getSubscriptionId(), operator);
                return;
            }
            askSim(subs, code, operator);
        } catch (SecurityException e) {
            toast("Autorisation téléphone refusée.");
        } catch (Exception e) {
            toast("Impossible de lancer le paiement.");
        }
    }

    private static String opName(String operator) {
        return "moov".equalsIgnoreCase(operator) ? "Moov Money" : "Orange Money";
    }

    /** SIM de l'opérateur choisi (nom d'opérateur ou code réseau 610 01 / 610 02), sinon null. */
    private SubscriptionInfo matchSub(List<SubscriptionInfo> subs, String operator) {
        if (operator == null) return null;
        final String op = operator.toLowerCase(Locale.ROOT);
        final String[] words;
        final String mccmnc;
        if (op.equals("orange")) {
            words = new String[]{"orange"};
            mccmnc = "61002"; // Orange Mali = 610 02
        } else if (op.equals("moov")) {
            words = new String[]{"moov", "malitel"};
            mccmnc = "61001"; // Moov Africa (Malitel) = 610 01
        } else {
            return null;
        }
        // 1) par nom d'opérateur, 2) par code réseau (évite qu'un code ne l'emporte sur un nom clair)
        for (SubscriptionInfo si : subs) {
            String t = (si.getCarrierName() + " " + si.getDisplayName()).toLowerCase(Locale.ROOT);
            for (String w : words) {
                if (t.contains(w)) return si;
            }
        }
        for (SubscriptionInfo si : subs) {
            String mcc = Build.VERSION.SDK_INT >= 29 ? si.getMccString() : String.valueOf(si.getMcc());
            String mnc = Build.VERSION.SDK_INT >= 29 ? si.getMncString() : String.valueOf(si.getMnc());
            if ((mcc + mnc).equals(mccmnc)) return si;
        }
        return null;
    }

    /** SIM non reconnue automatiquement : on demande au client laquelle utiliser (sans montrer le code). */
    private void askSim(final List<SubscriptionInfo> subs, final String code, final String operator) {
        String[] labels = new String[subs.size()];
        for (int i = 0; i < labels.length; i++) {
            labels[i] = subs.get(i).getDisplayName() + "  (SIM " + (i + 1) + ")";
        }
        new android.app.AlertDialog.Builder(this)
                .setTitle("Quelle SIM utiliser pour " + opName(operator) + " ?")
                .setItems(labels, (d, which) -> {
                    try {
                        sendUssd(code, subs.get(which).getSubscriptionId(), operator);
                    } catch (Exception e) {
                        toast("Impossible de lancer le paiement.");
                    }
                })
                .setNegativeButton("Annuler", null)
                .show();
    }

    private android.app.AlertDialog ussdDialog;

    private void closeUssdDialog() {
        if (ussdDialog != null) {
            try { ussdDialog.dismiss(); } catch (Exception ignored) { }
            ussdDialog = null;
        }
    }

    /**
     * v1.11 : le paiement passe par l'appel système (TelecomManager.placeCall) sur la SIM choisie.
     * Contrairement à sendUssdRequest (qui ne permet pas de répondre à un menu), la fenêtre USSD
     * de l'opérateur s'affiche avec son champ de saisie : le client y tape son code secret et
     * valide. Le code USSD n'apparaît pas dans un composeur ; le SMS de confirmation est ensuite
     * détecté automatiquement par SmsReceiver (déjà armé par la page).
     */
    private void sendUssd(final String code, int subId, final String operator) {
        closeUssdDialog();
        try {
            TelecomManager tcm = (TelecomManager) getSystemService(TELECOM_SERVICE);
            Bundle extras = new Bundle();
            PhoneAccountHandle h = handleFor(subId);
            if (h != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h);
            tcm.placeCall(Uri.fromParts("tel", code, null), extras);
            notifyPage("dialed", "");
            toast("Saisissez votre code secret " + opName(operator) + " dans la fenêtre qui s'ouvre.");
        } catch (SecurityException e) {
            toast("Autorisation téléphone refusée.");
        } catch (Exception e) {
            toast("Impossible de lancer le paiement.");
        }
    }

    /** Compte d'appel (PhoneAccountHandle) correspondant à la SIM choisie, sinon null (le téléphone demandera la SIM). */
    @SuppressLint("MissingPermission")
    private PhoneAccountHandle handleFor(int subId) {
        try {
            TelecomManager tcm = (TelecomManager) getSystemService(TELECOM_SERVICE);
            TelephonyManager base = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            List<PhoneAccountHandle> hs = tcm.getCallCapablePhoneAccounts();
            if (hs == null) return null;
            for (PhoneAccountHandle h : hs) {
                if (Build.VERSION.SDK_INT >= 30) {
                    TelephonyManager t = base.createForPhoneAccountHandle(h);
                    if (t != null && t.getSubscriptionId() == subId) return h;
                } else if (String.valueOf(subId).equals(h.getId())) {
                    return h;
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Prévient la page (facultatif) : window.onMayaUssd(statut, texte). Rien n'est stocké. */
    private void notifyPage(String status, String text) {
        if (!isTrustedPage()) return;
        web.evaluateJavascript("window.onMayaUssd&&window.onMayaUssd("
                + JSONObject.quote(status) + "," + JSONObject.quote(text) + ")", null);
    }

    /** Dernier recours : appel système (la SIM est demandée par le téléphone). */
    private void systemCall(String code) {
        try {
            TelecomManager tm = (TelecomManager) getSystemService(TELECOM_SERVICE);
            tm.placeCall(Uri.fromParts("tel", code, null), new Bundle());
        } catch (Exception e) {
            toast("Impossible de lancer le paiement.");
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }
}
