package com.mayapay.app;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Pattern;

/**
 * Détection automatique des SMS de confirmation Orange Money / Moov Money.
 *
 * Actif seulement pendant un paiement : la page appelle MayaNative.armSms(...) qui mémorise le lien, l'opérateur,
 * le filtre du SMS et une échéance (10 min). Tout SMS qui ne correspond pas au filtre est ignoré : il n'est ni lu
 * plus loin, ni transmis, ni conservé, et la boîte de réception n'est jamais lue.
 * Un SMS correspondant est envoyé directement au serveur (mayapay_sms_v2) avec sa date de réception et le numéro
 * de la SIM qui l'a reçu. Le serveur vérifie tout et décide ; la page affiche le résultat qu'elle lit sur le serveur.
 */
public class SmsReceiver extends BroadcastReceiver {

    static final String PREFS = "maya_sms";
    // Filtre de secours si le serveur n'en fournit pas : tout SMS parlant de FCFA.
    private static final Pattern FALLBACK = Pattern.compile("(fcfa|xof|\\bcfa\\b)", Pattern.CASE_INSENSITIVE);

    /** Mémorise le paiement à surveiller (appelé par la page de confiance). */
    static void arm(Context c, String linkId, String operator, String filter, int minutes) {
        long until = System.currentTimeMillis() + Math.max(1, Math.min(minutes, 15)) * 60_000L;
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("id", linkId).putString("op", operator).putString("filter", filter == null ? "" : filter)
                .putLong("until", until).apply();
    }

    static void disarm(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply();
    }

    static boolean isArmed(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return sp.getString("id", null) != null && System.currentTimeMillis() <= sp.getLong("until", 0);
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        if (intent == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final String id = sp.getString("id", null);
        final String op = sp.getString("op", null);
        String filter = sp.getString("filter", "");
        if (id == null || op == null) return;
        if (System.currentTimeMillis() > sp.getLong("until", 0)) { disarm(ctx); return; }

        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null || parts.length == 0) return;
        StringBuilder body = new StringBuilder();
        String address = null;
        long ts = 0;
        for (SmsMessage m : parts) {
            if (m == null) continue;
            if (m.getMessageBody() != null) body.append(m.getMessageBody());
            if (address == null) address = m.getOriginatingAddress();
            if (ts == 0) ts = m.getTimestampMillis();
        }
        final String text = body.toString();
        if (text.length() < 20) return;

        Pattern p;
        try {
            p = (filter == null || filter.isEmpty() || filter.length() > 400) ? FALLBACK : Pattern.compile(filter);
        } catch (Exception e) {
            p = FALLBACK;
        }
        if (!p.matcher(text).find()) return; // SMS sans rapport : ignoré

        final long received = ts > 0 ? ts : System.currentTimeMillis();
        final String addr = address == null ? "" : address;
        final String device = deviceNumber(ctx, intent.getIntExtra("subscription", -1));
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                String status = post(id, op, text, received, device, addr);
                // Confirmé ou transmis au vendeur : le paiement est terminé. Sinon on attend le bon SMS jusqu'à l'échéance.
                if ("confirmed".equals(status) || "check".equals(status)) disarm(ctx);
            } finally {
                pr.finish();
            }
        }).start();
    }

    /** Numéro de la SIM qui a reçu le SMS, si le téléphone l'indique (sinon vide). */
    @SuppressLint({"MissingPermission", "HardwareIds"})
    private static String deviceNumber(Context c, int subId) {
        try {
            if (c.checkSelfPermission(android.Manifest.permission.READ_PHONE_NUMBERS) != PackageManager.PERMISSION_GRANTED
                    && c.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
            if (Build.VERSION.SDK_INT >= 33 && subId >= 0) {
                SubscriptionManager sm = c.getSystemService(SubscriptionManager.class);
                String n = sm == null ? null : sm.getPhoneNumber(subId);
                if (n != null && !n.isEmpty()) return n;
            }
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return "";
            if (subId >= 0) tm = tm.createForSubscriptionId(subId);
            String n = tm.getLine1Number();
            return n == null ? "" : n;
        } catch (Throwable t) {
            return "";
        }
    }

    /** Envoie le SMS au serveur (2 essais). Retourne le statut renvoyé, ou "" en cas d'échec réseau. */
    private static String post(String id, String op, String text, long received, String device, String address) {
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        String payload;
        try {
            payload = new JSONObject()
                    .put("p_id", id).put("p_operator", op).put("p_message", text)
                    .put("p_received_at", iso.format(new Date(received)))
                    .put("p_device_number", device).put("p_address", address).toString();
        } catch (Exception e) {
            return "";
        }
        for (int attempt = 0; attempt < 2; attempt++) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(BuildConfig.SUPABASE_URL + "/rest/v1/rpc/mayapay_sms_v2").openConnection();
                con.setRequestMethod("POST");
                con.setConnectTimeout(8000);
                con.setReadTimeout(8000);
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json");
                con.setRequestProperty("apikey", BuildConfig.SUPABASE_KEY);
                try (OutputStream os = con.getOutputStream()) {
                    os.write(payload.getBytes(StandardCharsets.UTF_8));
                }
                if (con.getResponseCode() / 100 == 2) {
                    java.io.InputStream is = con.getInputStream();
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[1024];
                    int n;
                    while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                    return new JSONObject(bo.toString("UTF-8")).optString("status", "");
                }
            } catch (Exception ignored) {
                // nouvel essai
            } finally {
                if (con != null) con.disconnect();
            }
        }
        return "";
    }
}
